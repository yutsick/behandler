=== ACF Code Generator ===
Contributors: Deepak anand
Donate link: 
Tags:  acf code generator, ACF, ACF code, code generator, acf get field
Requires at least: 4.0
Tested up to: 5.7.1
Stable tag: trunk
Requires PHP: 5.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

This plugin is intended to continue the development of the "ACF Theme Code" plugin as there are no updates for that plugin for the last 12 months(for three major WP updates).

Always look into the ACF(Advanced Custom Fields) documentation to get the different types of ACF fields?

Forget the documentation. This tinny WordPress plugin can generate all the code for you so that you don't need to roam here and there to search the code of the ACF plugin.

== Description ==

This plugin is intended to continue the development of the "ACF Theme Code" plugin as there are no updates for that plugin for the last 12 months(for three major WP updates).

Always look into the ACF (Advanced Custom Fields) documentation to get the different types of ACF fields?

Forget the documentation. This tinny WordPress plugin can generate all the code for you so that you don't need to roam here and there to search the code of the ACF plugin.

Check the screenshots for more details.

### Code can be generated for the following fields:

- Text
- Text Area
- Number
- Range
- Email
- URL
- Password
- Image
- File
- WYSIWYG
- oEmbed
- Select
- Checkbox
- Radio Button
- Button Group
- True / False
- Link
- Post Object
- Page Link
- Relationship
- Taxonomy
- User
- Google Map
- Date Picker
- Date Time Picker
- Color Picker
- Group

== Installation ==

Just like other plugins, this plugin can also be installed using the normal installation steps given below:

1. Upload the plugin files to the `/wp-content/plugins/acf-code-generator` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress

== Frequently Asked Questions ==


== Screenshots ==

1. This is how the code will look in the custom fields section.

== Changelog ==


== Upgrade Notice ==

