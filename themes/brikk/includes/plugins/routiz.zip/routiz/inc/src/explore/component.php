<?php

namespace Routiz\Inc\Src\Explore;

use \Routiz\Inc\Src\Traits\Singleton;
use \Routiz\Inc\Extensions\Component\Component as Main_Component;

class Component extends Main_Component {

    use Singleton;

}
