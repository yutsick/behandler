<input
    type="hidden"
    name="{{ $id }}"
    value="{{ $value }}">
