<?php

namespace Routiz\Inc\Src\Form\Modules\Tab;

use \Routiz\Inc\Src\Form\Modules\Module;

class Tab extends Module {

    // ..

}
