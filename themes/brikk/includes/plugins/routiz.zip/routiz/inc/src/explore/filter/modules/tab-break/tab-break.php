<?php

namespace Routiz\Inc\Src\Explore\Filter\Modules\Tab_Break;

use \Routiz\Inc\Src\Explore\Filter\Modules\Module;
use \Routiz\Inc\Src\Explore\Filter\Comparison;

class Tab_Break extends Module {

    public function query() {
        return [];
    }

    public function get() {}

}
