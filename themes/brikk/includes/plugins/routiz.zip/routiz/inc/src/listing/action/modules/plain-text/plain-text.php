<?php

namespace Routiz\Inc\Src\Listing\Action\Modules\Plain_Text;

use \Routiz\Inc\Src\User;
use \Routiz\Inc\Src\Listing\Action\Modules\Module;
use \Routiz\Inc\Src\Listing\Listing;

class Plain_Text extends Module {

    // ..

}
