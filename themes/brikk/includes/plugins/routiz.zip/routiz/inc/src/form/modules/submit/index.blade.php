<div class="">
    <input class="rz-button {{ $button->class }}" {!! $button->id !!} type="submit" value="{{ $name }}">
</div>
