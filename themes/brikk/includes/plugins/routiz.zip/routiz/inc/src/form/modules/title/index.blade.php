<div class="rz-just-title">
    <{{ $tag }} class="rz-the-title">{{ $name }}</{{ $tag }}>
    @if( $description )
        <p>{{ $description }}</p>
    @endif
</div>
