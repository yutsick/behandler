@php
    wp_nonce_field( $value, $id );
@endphp