<div class="rz-user-avatar">
    <div class="rz-user-avatar-img">
        <i class="fas fa-user"></i>
    </div>
</div>