<?php

defined('ABSPATH') || exit;

?>

<div class="rz-preloader">
    <i class="fas fa-sync"></i>
</div>
