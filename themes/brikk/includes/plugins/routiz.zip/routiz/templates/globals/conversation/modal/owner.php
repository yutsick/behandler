<?php

defined('ABSPATH') || exit;

?>

<div class="rz-modal-container rz-scrollbar">
    <div class="rz--icon">
        <i class="fas fa-ban"></i>
        <p class="rz-mb-3"><?php esc_html_e( 'You can\'t message yourself', 'routiz' ); ?></p>
    </div>
</div>
