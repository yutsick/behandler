<?php

defined('ABSPATH') || exit;

?>

<div class="rz-favorites">
    <a href="#" class="rz-favorites-icon" data-modal="favorites">
        <i class="far fa-heart"></i>
    </a>
</div>
