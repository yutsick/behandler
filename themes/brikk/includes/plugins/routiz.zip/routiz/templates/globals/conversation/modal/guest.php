<?php

defined('ABSPATH') || exit;

?>

<div class="rz--icon">
    <i class="fas fa-ban"></i>
    <p><?php esc_html_e( 'You need to login in order to send messages', 'routiz' ); ?></p>
</div>