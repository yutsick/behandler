<?php get_header(); ?>

<div class="rz-container">
	<?php the_content(); ?>
</div>

<?php get_footer();
